#!/usr/bin/env python3
from experiments.paper_ablation import main

if __name__ == "__main__":
    main()
